To make the NaiveBayes.py run you only need to call it like this:
python NaiveBayes.py
The script will read the two file provided and write to the a csv file named Naive_Bayes_Guess.csv